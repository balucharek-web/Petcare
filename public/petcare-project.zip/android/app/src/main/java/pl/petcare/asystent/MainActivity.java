package pl.petcare.asystent;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
