import os
import zipfile

IGNORED_DIRS = {'.git', 'node_modules', 'dev-dist', 'dist', '.cache'}
IGNORED_EXTS = {'.pyc'}

output_zip_path = 'public/petcare-project.zip'

with zipfile.ZipFile(output_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in IGNORED_DIRS and not d.startswith('.git')]
        for file in files:
            if file == 'petcare-project.zip' or any(file.endswith(ext) for ext in IGNORED_EXTS):
                continue
            full_path = os.path.join(root, file)
            arcname = os.path.relpath(full_path, '.')
            # Keep clean relative paths
            zipf.write(full_path, arcname)

print(f"Created {output_zip_path} successfully. Size: {os.path.getsize(output_zip_path)} bytes")
