import React, { useState } from 'react';
import { 
  Heart, 
  Edit3, 
  Scale, 
  Sparkles, 
  AlertCircle, 
  Copy, 
  Check, 
  Phone, 
  Calendar as CalendarIcon, 
  ShieldCheck, 
  Trash2, 
  Plus, 
  Camera, 
  Info,
  Activity,
  BookOpen,
  Paperclip,
  Eye,
  FileText
} from 'lucide-react';
import { Pet, PetWeightEntry } from '../types/pet';
import { storage } from '../services/storage';
import { ScanViewerModal } from './ScanViewerModal';

interface PetProfileViewProps {
  pet: Pet;
  onUpdatePet: (updated: Pet) => void;
  onDeletePet?: (petId: string) => void;
  onOpenNewPetModal: () => void;
  totalVaccinationsCount: number;
  activeMedicationsCount: number;
  onNavigateToTab: (tab: any) => void;
}

export const PetProfileView: React.FC<PetProfileViewProps> = ({
  pet,
  onUpdatePet,
  onDeletePet,
  onOpenNewPetModal,
  totalVaccinationsCount,
  activeMedicationsCount,
  onNavigateToTab,
}) => {
  const [copiedChip, setCopiedChip] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isAddingWeight, setIsAddingWeight] = useState(false);
  const [newWeight, setNewWeight] = useState('');
  const [newWeightNotes, setNewWeightNotes] = useState('');
  const [previewBookletScan, setPreviewBookletScan] = useState<{ url: string; title: string; date?: string } | null>(null);

  // Edit form state
  const [editForm, setEditForm] = useState<Partial<Pet>>({ ...pet });

  const handleBookletScanUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const url = ev.target?.result as string;
      if (url) {
        const newScan = {
          id: `bk-${Date.now()}`,
          url,
          title: file.name ? file.name.replace(/\.[^/.]+$/, '') : `Książeczka zdrowia - str. ${(pet.bookletScans?.length || 0) + 1}`,
          date: new Date().toISOString().slice(0, 10),
        };
        const updatedBookletScans = [...(pet.bookletScans || []), newScan];
        onUpdatePet({
          ...pet,
          bookletScans: updatedBookletScans,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDeleteBookletScan = (scanId: string) => {
    const updatedBookletScans = (pet.bookletScans || []).filter(s => s.id !== scanId);
    onUpdatePet({
      ...pet,
      bookletScans: updatedBookletScans,
    });
  };

  const calculateAge = (birthDate: string): string => {
    if (!birthDate) return '-';
    const birth = new Date(birthDate);
    const now = new Date();
    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    if (months < 0 || (months === 0 && now.getDate() < birth.getDate())) {
      years--;
      months += 12;
    }
    if (years === 0) {
      return `${months} ${months === 1 ? 'miesiąc' : months < 5 ? 'miesiące' : 'miesięcy'}`;
    }
    const yearStr = years === 1 ? 'rok' : years < 5 ? 'lata' : 'lat';
    return `${years} ${yearStr} ${months > 0 ? `i ${months} mies.` : ''}`;
  };

  const copyChip = () => {
    if (pet.chipNumber) {
      navigator.clipboard.writeText(pet.chipNumber);
      setCopiedChip(true);
      setTimeout(() => setCopiedChip(false), 2000);
    }
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Pet = {
      ...pet,
      ...editForm,
      weightKg: Number(editForm.weightKg) || pet.weightKg,
    };
    onUpdatePet(updated);
    setIsEditing(false);
  };

  const handleAddWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(newWeight);
    if (isNaN(w) || w <= 0) return;
    const newEntry: PetWeightEntry = {
      id: `w-${Date.now()}`,
      date: new Date().toISOString().slice(0, 10),
      weightKg: w,
      notes: newWeightNotes.trim() || undefined,
    };
    const updated: Pet = {
      ...pet,
      weightKg: w,
      weightHistory: [...(pet.weightHistory || []), newEntry],
    };
    onUpdatePet(updated);
    setNewWeight('');
    setNewWeightNotes('');
    setIsAddingWeight(false);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const url = ev.target?.result as string;
      if (url) {
        setEditForm(prev => ({ ...prev, photoUrl: url }));
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-5 pb-24 animate-fadeIn">
      {/* Hero Card */}
      <div className="relative bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-gradient-to-bl from-teal-500/10 via-emerald-500/5 to-transparent rounded-bl-full pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
          {/* Pet Photo */}
          <div className="relative group shrink-0">
            <img
              src={pet.photoUrl || 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=300&q=80'}
              alt={pet.name}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-3xl object-cover ring-4 ring-teal-500/20 shadow-md"
            />
            <button
              onClick={() => {
                setEditForm({ ...pet });
                setIsEditing(true);
              }}
              title="Edytuj profil zwierzaka"
              className="absolute -bottom-2 -right-2 p-2 bg-teal-600 hover:bg-teal-700 text-white rounded-2xl shadow-md active:scale-95 transition"
            >
              <Edit3 className="w-4 h-4" />
            </button>
          </div>

          {/* Details */}
          <div className="flex-1 text-center sm:text-left min-w-0">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                    {pet.name}
                  </h1>
                  <span className="text-xl">
                    {pet.species === 'dog' ? '🐶' : pet.species === 'cat' ? '🐱' : '🐰'}
                  </span>
                </div>
                <p className="text-sm font-medium text-slate-600">
                  {pet.breed || 'Mieszaniec'} • {pet.gender === 'female' ? 'Suczka / Samica' : 'Pies / Samiec'}
                </p>
              </div>

              <button
                onClick={() => {
                  setEditForm({ ...pet });
                  setIsEditing(true);
                }}
                className="self-center sm:self-start flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition"
              >
                <Edit3 className="w-3.5 h-3.5" />
                Edytuj dane
              </button>
            </div>

            {/* Quick Metrics Badges */}
            <div className="grid grid-cols-3 gap-2 mt-4">
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100 text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Wiek</span>
                <span className="text-xs sm:text-sm font-bold text-slate-800 truncate block">
                  {calculateAge(pet.birthDate)}
                </span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100 text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Waga</span>
                <span className="text-xs sm:text-sm font-bold text-teal-700 truncate block">
                  {pet.weightKg} kg
                </span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-2xl border border-slate-100 text-center">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Kastracja</span>
                <span className="text-xs sm:text-sm font-bold text-slate-800 truncate block">
                  {pet.isNeutered ? 'Tak' : 'Nie'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Shortcut Buttons for other tabs */}
        <div className="grid grid-cols-2 gap-2 mt-5 pt-4 border-t border-slate-100">
          <button
            onClick={() => onNavigateToTab('medications')}
            className="flex items-center justify-between p-3 rounded-2xl bg-teal-50/80 hover:bg-teal-100/80 text-teal-900 transition text-left"
          >
            <div>
              <span className="text-[10px] font-bold uppercase text-teal-600">Dzisiejsze leki</span>
              <p className="font-bold text-xs">{activeMedicationsCount} aktywnych leków</p>
            </div>
            <span className="text-base">💊</span>
          </button>

          <button
            onClick={() => onNavigateToTab('vaccinations')}
            className="flex items-center justify-between p-3 rounded-2xl bg-emerald-50/80 hover:bg-emerald-100/80 text-emerald-900 transition text-left"
          >
            <div>
              <span className="text-[10px] font-bold uppercase text-emerald-600">Szczepienia</span>
              <p className="font-bold text-xs">{totalVaccinationsCount} wpisów</p>
            </div>
            <span className="text-base">💉</span>
          </button>
        </div>
      </div>

      {/* Microchip & Passport Card */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-slate-100 rounded-xl text-slate-700">
              <ShieldCheck className="w-5 h-5 text-teal-600" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Mikroczip i Dokumenty</h2>
              <p className="text-xs text-slate-400">Identyfikacja zwierzaka w bazie Safe-Animal / CBDZ</p>
            </div>
          </div>

          {pet.chipNumber && (
            <button
              onClick={copyChip}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                copiedChip ? 'bg-emerald-600 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {copiedChip ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedChip ? 'Skopiowano' : 'Kopiuj'}
            </button>
          )}
        </div>

        <div className="bg-slate-900 text-white rounded-2xl p-4 font-mono">
          <div className="flex justify-between items-center text-xs text-slate-400 mb-1">
            <span>TRANS-PONDER CHIP</span>
            <span>15 CYFR ISO</span>
          </div>
          <div className="text-lg sm:text-xl font-bold tracking-widest text-teal-300">
            {pet.chipNumber || 'Brak wpisanego chipa'}
          </div>
          {/* Simulated barcode stripes */}
          <div className="mt-3 flex items-center justify-between gap-1 opacity-70 h-6 overflow-hidden">
            {[...Array(36)].map((_, i) => (
              <div
                key={i}
                className="bg-white h-full"
                style={{
                  width: `${(i % 3) + 1}px`,
                  opacity: i % 2 === 0 ? 0.9 : 0.4,
                }}
              />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-3 text-xs">
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Nr Paszportu</span>
            <span className="font-semibold text-slate-800">{pet.passportNumber || 'Brak'}</span>
          </div>
          <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">Nr Tatuażu</span>
            <span className="font-semibold text-slate-800">{pet.tattooNumber || 'Brak'}</span>
          </div>
        </div>
      </div>

      {/* Physical Health Booklet Scans (Książeczka Zdrowia - Skany stron i okładki) */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-amber-50 rounded-xl text-amber-700">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Książeczka Zdrowia (Skany)</h2>
              <p className="text-xs text-slate-400">Zdjęcia fizycznej książeczki weterynaryjnej</p>
            </div>
          </div>
          <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold cursor-pointer transition shadow-xs">
            <Camera className="w-3.5 h-3.5" />
            <span>Dodaj stronę</span>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleBookletScanUpload}
              className="hidden"
            />
          </label>
        </div>

        {(!pet.bookletScans || pet.bookletScans.length === 0) ? (
          <div className="p-4 rounded-2xl bg-amber-50/50 border border-dashed border-amber-200 text-center">
            <Paperclip className="w-6 h-6 text-amber-500 mx-auto mb-1.5 opacity-60" />
            <p className="text-xs font-semibold text-slate-700">Brak wgranych skanów książeczki</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Zrób zdjęcie stron fizycznej książeczki zdrowia (szczepienia, wpisy, pieczątki lekarza), aby mieć je zawsze przy sobie w telefonie.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {pet.bookletScans.map((scan) => (
              <div
                key={scan.id}
                className="group relative rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 aspect-3/4 flex flex-col justify-end shadow-xs hover:shadow-md transition"
              >
                <img
                  src={scan.url}
                  alt={scan.title}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/85 via-slate-900/20 to-transparent pointer-events-none" />

                <div className="relative p-2.5 z-10 text-white">
                  <p className="text-xs font-bold truncate leading-tight">{scan.title}</p>
                  <p className="text-[10px] text-slate-300">{scan.date}</p>
                </div>

                {/* Actions overlay */}
                <div className="absolute top-2 right-2 flex gap-1.5 z-20">
                  <button
                    type="button"
                    onClick={() => setPreviewBookletScan({ url: scan.url, title: scan.title, date: scan.date })}
                    className="p-1.5 rounded-lg bg-black/60 hover:bg-black text-white backdrop-blur-xs transition"
                    title="Powiększ i zobacz"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteBookletScan(scan.id)}
                    className="p-1.5 rounded-lg bg-red-600/80 hover:bg-red-700 text-white backdrop-blur-xs transition"
                    title="Usuń stronę"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Weight History Tracker */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-teal-50 rounded-xl text-teal-700">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Kontrola Wagi</h2>
              <p className="text-xs text-slate-400">Aktualna: <strong className="text-teal-700">{pet.weightKg} kg</strong></p>
            </div>
          </div>
          <button
            onClick={() => setIsAddingWeight(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-50 text-teal-700 hover:bg-teal-100 text-xs font-bold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            Nowy pomiar
          </button>
        </div>

        {/* Weight history list */}
        <div className="space-y-2">
          {(!pet.weightHistory || pet.weightHistory.length === 0) ? (
            <p className="text-xs text-slate-400 text-center py-2">Brak wcześniejszych pomiarów wagi.</p>
          ) : (
            pet.weightHistory.slice(-4).reverse().map((entry) => (
              <div
                key={entry.id}
                className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-teal-500" />
                  <span className="font-semibold text-slate-700">{entry.date}</span>
                  {entry.notes && <span className="text-slate-400 italic">({entry.notes})</span>}
                </div>
                <span className="font-bold text-slate-900 bg-white px-2.5 py-1 rounded-xl shadow-xs border border-slate-100">
                  {entry.weightKg} kg
                </span>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Allergies & Special Medical Notes */}
      {(pet.allergies || pet.specialNotes || pet.color) && (
        <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 space-y-3">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Info className="w-4 h-4 text-teal-600" />
            Cechy i Ostrzeżenia Zdrowotne
          </h2>

          {pet.allergies && (
            <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-100 flex items-start gap-3">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] font-bold uppercase text-rose-700 block">Alergie i Nietolerancje</span>
                <p className="text-xs text-rose-900 font-medium">{pet.allergies}</p>
              </div>
            </div>
          )}

          {pet.specialNotes && (
            <div className="p-3.5 rounded-2xl bg-blue-50 border border-blue-100">
              <span className="text-[10px] font-bold uppercase text-blue-700 block mb-1">Uwagi Behawioralne i Opiekuńcze</span>
              <p className="text-xs text-blue-900 leading-relaxed">{pet.specialNotes}</p>
            </div>
          )}

          {pet.color && (
            <div className="text-xs text-slate-600 flex justify-between py-1 border-t border-slate-100 pt-2">
              <span>Umaszczenie / Cechy szczególne:</span>
              <strong className="text-slate-800">{pet.color}</strong>
            </div>
          )}
        </div>
      )}

      {/* Vet Clinic Card */}
      <div className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80">
        <h2 className="text-sm font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Phone className="w-4 h-4 text-teal-600" />
          Twój Weterynarz
        </h2>

        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-500">Przychodnia:</span>
            <strong className="text-slate-800">{pet.vetClinicName || 'Nie ustawiono'}</strong>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Lekarz:</span>
            <strong className="text-slate-800">{pet.vetDoctorName || '-'}</strong>
          </div>
          {pet.vetPhone && (
            <div className="flex justify-between items-center pt-2 border-t border-slate-200">
              <span className="text-slate-500">Telefon do gabinetu:</span>
              <a
                href={`tel:${pet.vetPhone}`}
                className="font-bold text-teal-700 hover:text-teal-800 bg-white px-2.5 py-1 rounded-xl border border-slate-200"
              >
                {pet.vetPhone}
              </a>
            </div>
          )}
          {pet.emergencyClinicPhone && (
            <div className="flex justify-between items-center pt-2 border-t border-slate-200">
              <span className="text-rose-600 font-semibold">Dyżur całodobowy:</span>
              <a
                href={`tel:${pet.emergencyClinicPhone}`}
                className="font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-xl border border-rose-200"
              >
                {pet.emergencyClinicPhone}
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Add Weight Modal */}
      {isAddingWeight && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <Scale className="w-5 h-5 text-teal-600" />
              Nowy pomiar wagi
            </h3>
            <form onSubmit={handleAddWeight} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">
                  Waga (kg)
                </label>
                <input
                  type="number"
                  step="0.05"
                  required
                  autoFocus
                  placeholder="np. 28.5"
                  value={newWeight}
                  onChange={(e) => setNewWeight(e.target.value)}
                  className="w-full p-3 rounded-2xl bg-slate-50 border border-slate-200 text-base font-bold text-slate-800 focus:outline-teal-600"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-600 block mb-1">
                  Notatka (opcjonalnie)
                </label>
                <input
                  type="text"
                  placeholder="np. Po wizycie kontrolnej, ważenie domowe"
                  value={newWeightNotes}
                  onChange={(e) => setNewWeightNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 focus:outline-teal-600"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingWeight(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs shadow transition"
                >
                  Zapisz wagę
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Pet Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">Edytuj profil: {pet.name}</h3>
              <button
                onClick={() => setIsEditing(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              {/* Photo & Name */}
              <div className="flex items-center gap-4">
                <div className="relative">
                  <img
                    src={editForm.photoUrl || 'https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=150&q=80'}
                    alt="Podgląd"
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-teal-500"
                  />
                  <label className="absolute -bottom-1 -right-1 p-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl shadow cursor-pointer">
                    <Camera className="w-3.5 h-3.5" />
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <div className="flex-1 space-y-1">
                  <label className="font-semibold text-slate-600 block">Imię zwierzaka *</label>
                  <input
                    type="text"
                    required
                    value={editForm.name || ''}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-800 focus:outline-teal-600"
                  />
                </div>
              </div>

              {/* Photo URL manual option */}
              <div>
                <label className="font-semibold text-slate-600 block mb-0.5">Link do zdjęcia (URL)</label>
                <input
                  type="url"
                  placeholder="https://..."
                  value={editForm.photoUrl || ''}
                  onChange={(e) => setEditForm({ ...editForm, photoUrl: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                />
              </div>

              {/* Species, Breed, Gender */}
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Gatunek</label>
                  <select
                    value={editForm.species || 'dog'}
                    onChange={(e) => setEditForm({ ...editForm, species: e.target.value as any })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  >
                    <option value="dog">Pies</option>
                    <option value="cat">Kot</option>
                    <option value="rabbit">Królik</option>
                    <option value="ferret">Fretka</option>
                    <option value="other">Inny</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Płeć</label>
                  <select
                    value={editForm.gender || 'female'}
                    onChange={(e) => setEditForm({ ...editForm, gender: e.target.value as any })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  >
                    <option value="female">Samica</option>
                    <option value="male">Samiec</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Kastracja</label>
                  <select
                    value={editForm.isNeutered ? 'yes' : 'no'}
                    onChange={(e) => setEditForm({ ...editForm, isNeutered: e.target.value === 'yes' })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  >
                    <option value="yes">Tak</option>
                    <option value="no">Nie</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Rasa</label>
                  <input
                    type="text"
                    placeholder="np. Golden Retriever"
                    value={editForm.breed || ''}
                    onChange={(e) => setEditForm({ ...editForm, breed: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Data urodzenia</label>
                  <input
                    type="date"
                    value={editForm.birthDate || ''}
                    onChange={(e) => setEditForm({ ...editForm, birthDate: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
              </div>

              {/* Chip & Passport */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Numer Mikroczipa *</label>
                  <input
                    type="text"
                    placeholder="15 cyfr"
                    value={editForm.chipNumber || ''}
                    onChange={(e) => setEditForm({ ...editForm, chipNumber: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono font-semibold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Numer Paszportu</label>
                  <input
                    type="text"
                    placeholder="np. PL-0984214"
                    value={editForm.passportNumber || ''}
                    onChange={(e) => setEditForm({ ...editForm, passportNumber: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-mono"
                  />
                </div>
              </div>

              {/* Weight & Color */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Waga (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={editForm.weightKg || ''}
                    onChange={(e) => setEditForm({ ...editForm, weightKg: parseFloat(e.target.value) || 0 })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-600 block mb-1">Umaszczenie</label>
                  <input
                    type="text"
                    placeholder="np. Złoty, tricolor"
                    value={editForm.color || ''}
                    onChange={(e) => setEditForm({ ...editForm, color: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
              </div>

              {/* Allergies & Notes */}
              <div>
                <label className="font-semibold text-slate-600 block mb-1">Alergie i Nietolerancje</label>
                <input
                  type="text"
                  placeholder="np. Kurczak, pyłki, leki z penicyliną"
                  value={editForm.allergies || ''}
                  onChange={(e) => setEditForm({ ...editForm, allergies: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                />
              </div>

              <div>
                <label className="font-semibold text-slate-600 block mb-1">Uwagi szczególne</label>
                <textarea
                  rows={2}
                  placeholder="np. Boi się obcych psów, lęk separacyjny, lubi smaczki z wątróbką"
                  value={editForm.specialNotes || ''}
                  onChange={(e) => setEditForm({ ...editForm, specialNotes: e.target.value })}
                  className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                />
              </div>

              {/* Vet Details */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <span className="font-bold text-slate-800 block text-[11px] uppercase tracking-wider">
                  Dane Przychodni Weterynaryjnej
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Nazwa kliniki"
                    value={editForm.vetClinicName || ''}
                    onChange={(e) => setEditForm({ ...editForm, vetClinicName: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                  <input
                    type="text"
                    placeholder="Lekarz prowadzący"
                    value={editForm.vetDoctorName || ''}
                    onChange={(e) => setEditForm({ ...editForm, vetDoctorName: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="tel"
                    placeholder="Telefon do weterynarza"
                    value={editForm.vetPhone || ''}
                    onChange={(e) => setEditForm({ ...editForm, vetPhone: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                  <input
                    type="tel"
                    placeholder="Telefon dyżur 24h (SOS)"
                    value={editForm.emergencyClinicPhone || ''}
                    onChange={(e) => setEditForm({ ...editForm, emergencyClinicPhone: e.target.value })}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold shadow transition"
                >
                  Zapisz zmiany
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Fullscreen Viewer for Physical Booklet Scans */}
      {previewBookletScan && (
        <ScanViewerModal
          isOpen={true}
          imageUrl={previewBookletScan.url}
          title={previewBookletScan.title}
          date={previewBookletScan.date}
          onClose={() => setPreviewBookletScan(null)}
        />
      )}
    </div>
  );
};
