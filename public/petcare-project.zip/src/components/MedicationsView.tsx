import React, { useState } from 'react';
import { 
  Pill, 
  Plus, 
  Calendar as CalendarIcon, 
  Clock, 
  Check, 
  Trash2, 
  Edit3, 
  ExternalLink, 
  Download, 
  Calculator,
  Info,
  Package,
  Layers,
  ChevronRight,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Pet, Medication, DoseScheduleItem } from '../types/pet';
import { storage } from '../services/storage';
import { 
  createGoogleCalendarUrl, 
  downloadICalendarFile, 
  buildMedicationCalendarEvent 
} from '../services/calendar';
import { calculateMedicationDemand, parseDoseToNumber } from '../services/dosageCalculator';

interface MedicationsViewProps {
  pet: Pet;
  medications: Medication[];
  onUpdateMedications: (items: Medication[]) => void;
}

const COMMON_DOSE_PRESETS = [
  { label: '¼ tab (0.25)', value: '1/4 tabletki' },
  { label: '½ tab (0.5)', value: '1/2 tabletki' },
  { label: '¾ tab (0.75)', value: '3/4 tabletki' },
  { label: '1 tab (1.0)', value: '1 tabletka' },
  { label: '1 ¼ tab', value: '1 1/4 tabletki' },
  { label: '1 ½ tab', value: '1 1/2 tabletki' },
  { label: '2 tab', value: '2 tabletki' },
];

export const MedicationsView: React.FC<MedicationsViewProps> = ({
  pet,
  medications,
  onUpdateMedications,
}) => {
  const [isAddingMed, setIsAddingMed] = useState(false);
  const [editingMed, setEditingMed] = useState<Medication | null>(null);
  const [medicationToDelete, setMedicationToDelete] = useState<Medication | null>(null);

  const todayStr = new Date().toISOString().slice(0, 10);
  const [doseLogs, setDoseLogs] = useState(() => storage.getDoseLogs(pet.id, todayStr));

  // Form State
  const [formName, setFormName] = useState('');
  const [formIngredient, setFormIngredient] = useState('');
  const [formForm, setFormForm] = useState<Medication['form']>('tablet');
  const [formDosage, setFormDosage] = useState('3/4 tabletki');
  const [formInstructions, setFormInstructions] = useState('Podawać z jedzeniem');
  const [formStartDate, setFormStartDate] = useState(todayStr);
  const [formEndDate, setFormEndDate] = useState('');
  const [formIsChronic, setFormIsChronic] = useState(true);
  const [formPackageSize, setFormPackageSize] = useState<string>('30');
  const [formCurrentStock, setFormCurrentStock] = useState<string>('');
  const [formTimes, setFormTimes] = useState<DoseScheduleItem[]>([
    { id: 't-1', label: 'Rano', time: '08:00', amount: '3/4 tabletki' },
    { id: 't-2', label: 'Wieczór', time: '20:00', amount: '3/4 tabletki' },
  ]);

  const activeMeds = medications.filter(m => m.isActive);
  const archivedMeds = medications.filter(m => !m.isActive);

  // Compute daily schedule items
  const dailySlots = activeMeds.flatMap(med => 
    med.timesOfDay.map(slot => ({
      medication: med,
      slot,
    }))
  ).sort((a, b) => a.slot.time.localeCompare(b.slot.time));

  const isDoseTaken = (medId: string, time: string) => {
    return doseLogs.some(l => l.medicationId === medId && l.time === time && l.scheduledDate === todayStr);
  };

  const handleToggleDose = (med: Medication, slot: DoseScheduleItem) => {
    const isNowTaken = storage.toggleDoseLog(pet.id, med.id, slot.time, todayStr);
    setDoseLogs(storage.getDoseLogs(pet.id, todayStr));

    if (isNowTaken) {
      try {
        confetti({
          particleCount: 35,
          spread: 55,
          origin: { y: 0.8 },
          colors: ['#0d9488', '#10b981', '#06b6d4'],
        });
      } catch {
        // Safe fallback
      }
    }
  };

  const handleOpenAdd = () => {
    setEditingMed(null);
    setFormName('');
    setFormIngredient('');
    setFormForm('tablet');
    setFormDosage('3/4 tabletki');
    setFormInstructions('Podawać z jedzeniem rano i wieczorem');
    setFormStartDate(todayStr);
    setFormEndDate('');
    setFormIsChronic(true);
    setFormPackageSize('30');
    setFormCurrentStock('');
    setFormTimes([
      { id: `t-${Date.now()}-1`, label: 'Rano', time: '08:00', amount: '3/4 tabletki' },
      { id: `t-${Date.now()}-2`, label: 'Wieczór', time: '20:00', amount: '3/4 tabletki' },
    ]);
    setIsAddingMed(true);
  };

  const handleOpenEdit = (med: Medication) => {
    setEditingMed(med);
    setFormName(med.name);
    setFormIngredient(med.activeIngredient || '');
    setFormForm(med.form);
    setFormDosage(med.dosage);
    setFormInstructions(med.instructions || '');
    setFormStartDate(med.startDate);
    setFormEndDate(med.endDate || '');
    setFormIsChronic(med.isChronic);
    setFormPackageSize(med.packageSize ? String(med.packageSize) : '30');
    setFormCurrentStock(med.currentStock !== undefined ? String(med.currentStock) : '');
    setFormTimes([...med.timesOfDay]);
    setIsAddingMed(true);
  };

  const handleAddTimeSlot = (defaultLabel = 'Południe', defaultTime = '13:00') => {
    setFormTimes(prev => [
      ...prev,
      {
        id: `t-${Date.now()}-${Math.random().toString(36).substr(2, 3)}`,
        label: defaultLabel,
        time: defaultTime,
        amount: formDosage || '3/4 tabletki',
      }
    ]);
  };

  const handleRemoveTimeSlot = (id: string) => {
    setFormTimes(prev => prev.filter(t => t.id !== id));
  };

  const handleUpdateTimeSlot = (id: string, field: keyof DoseScheduleItem, val: string) => {
    setFormTimes(prev => prev.map(t => t.id === id ? { ...t, [field]: val } : t));
  };

  // Quick preset applicator for a specific time slot or all slots
  const applyPresetToSlot = (slotId: string, presetVal: string) => {
    handleUpdateTimeSlot(slotId, 'amount', presetVal);
  };

  const applyPresetToAllSlots = (presetVal: string) => {
    setFormDosage(presetVal);
    setFormTimes(prev => prev.map(t => ({ ...t, amount: presetVal })));
  };

  // Preview calculation in the form
  const formDailyTotal = formTimes.reduce((sum, slot) => sum + parseDoseToNumber(slot.amount), 0);
  const formMonthlyDemand = Math.round(formDailyTotal * 30 * 10) / 10;
  const parsedPackageSize = parseFloat(formPackageSize);
  const formPackagesMonthly = parsedPackageSize > 0 
    ? Math.ceil(formMonthlyDemand / parsedPackageSize) 
    : null;

  const handleSaveMedication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (formTimes.length === 0) {
      alert('Dodaj co najmniej jedną porę dnia dla tego leku.');
      return;
    }

    const pkgSize = formPackageSize ? parseFloat(formPackageSize) : undefined;
    const curStock = formCurrentStock !== '' ? parseFloat(formCurrentStock) : undefined;

    if (editingMed) {
      const updated = medications.map(m => {
        if (m.id === editingMed.id) {
          return {
            ...m,
            name: formName.trim(),
            activeIngredient: formIngredient.trim() || undefined,
            form: formForm,
            dosage: formDosage.trim(),
            instructions: formInstructions.trim() || undefined,
            startDate: formStartDate,
            endDate: formEndDate ? formEndDate : undefined,
            isChronic: formIsChronic,
            packageSize: pkgSize,
            currentStock: curStock,
            timesOfDay: formTimes,
          };
        }
        return m;
      });
      onUpdateMedications(updated);
    } else {
      const newMed: Medication = {
        id: `med-${Date.now()}`,
        petId: pet.id,
        name: formName.trim(),
        activeIngredient: formIngredient.trim() || undefined,
        form: formForm,
        dosage: formDosage.trim() || '1 dawka',
        instructions: formInstructions.trim() || undefined,
        startDate: formStartDate,
        endDate: formEndDate ? formEndDate : undefined,
        isChronic: formIsChronic,
        isActive: true,
        packageSize: pkgSize,
        currentStock: curStock,
        timesOfDay: formTimes,
      };
      onUpdateMedications([...medications, newMed]);
    }

    setIsAddingMed(false);
  };

  const handleDeleteMedication = (med: Medication) => {
    setMedicationToDelete(med);
  };

  const confirmDeleteMedication = () => {
    if (!medicationToDelete) return;
    storage.deleteMedication(medicationToDelete.id);
    const updated = medications.filter(m => m.id !== medicationToDelete.id);
    onUpdateMedications(updated);
    if (editingMed?.id === medicationToDelete.id) {
      setIsAddingMed(false);
      setEditingMed(null);
    }
    setMedicationToDelete(null);
  };

  const handleToggleActiveMedication = (med: Medication) => {
    const updated = medications.map(m => m.id === med.id ? { ...m, isActive: !m.isActive } : m);
    onUpdateMedications(updated);
  };

  // Google Calendar integration
  const handleAddToGoogleCalendar = (med: Medication, slot?: DoseScheduleItem) => {
    const timeToUse = slot?.time || med.timesOfDay[0]?.time || '08:00';
    const amountToUse = slot?.amount || med.dosage;
    const event = buildMedicationCalendarEvent(
      pet.name,
      med.name,
      amountToUse,
      timeToUse,
      med.instructions,
      true
    );
    const url = createGoogleCalendarUrl(event);
    window.open(url, '_blank');
  };

  // Phone Calendar (.ics) integration
  const handleDownloadPhoneCalendar = (med: Medication, slot?: DoseScheduleItem) => {
    const events = (slot ? [slot] : med.timesOfDay).map(s => 
      buildMedicationCalendarEvent(pet.name, med.name, s.amount, s.time, med.instructions, true)
    );
    const filename = `Lek_${pet.name}_${med.name.replace(/\s+/g, '_')}`;
    downloadICalendarFile(filename, events);
  };

  return (
    <div className="space-y-5 pb-24 animate-fadeIn">
      {/* Top Banner with Today's Tracker */}
      <div className="bg-gradient-to-br from-teal-600 via-teal-700 to-emerald-800 text-white rounded-3xl p-5 shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-[10px] font-bold tracking-widest uppercase text-teal-200">
              Harmonogram na dziś
            </span>
            <h2 className="text-xl font-extrabold flex items-center gap-2">
              <Pill className="w-5 h-5 text-teal-300" />
              Dawkowanie Leków: {pet.name}
            </h2>
            <p className="text-xs text-teal-100 mt-0.5">
              {new Date().toLocaleDateString('pl-PL', { weekday: 'long', day: 'numeric', month: 'long' })}
            </p>
          </div>

          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-3 py-2 bg-white text-teal-800 hover:bg-teal-50 rounded-2xl text-xs font-bold shadow active:scale-95 transition"
          >
            <Plus className="w-4 h-4" />
            Dodaj lek
          </button>
        </div>

        {/* Interactive Today Doses Checklist */}
        {dailySlots.length === 0 ? (
          <div className="bg-white/10 rounded-2xl p-4 text-center text-xs text-teal-100">
            Brak zaplanowanych leków na dzisiaj. Kliknij „Dodaj lek”, aby utworzyć harmonogram!
          </div>
        ) : (
          <div className="space-y-2">
            {dailySlots.map(({ medication, slot }) => {
              const completed = isDoseTaken(medication.id, slot.time);

              return (
                <div
                  key={`${medication.id}-${slot.time}`}
                  onClick={() => handleToggleDose(medication, slot)}
                  className={`flex items-center justify-between p-3 rounded-2xl cursor-pointer transition select-none ${
                    completed
                      ? 'bg-emerald-900/40 border border-emerald-400/40 text-emerald-100'
                      : 'bg-white/15 hover:bg-white/20 border border-white/10 text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition ${
                        completed
                          ? 'bg-emerald-400 text-teal-950 font-bold shadow'
                          : 'border-2 border-white/50 text-transparent hover:border-white'
                      }`}
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                    </button>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`font-bold text-sm ${completed ? 'line-through opacity-80' : ''}`}>
                          {medication.name}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 font-semibold">
                          {slot.label} ({slot.time})
                        </span>
                      </div>
                      <p className="text-xs text-teal-100">
                        Dawka: <strong>{slot.amount}</strong>
                        {medication.instructions && ` • ${medication.instructions}`}
                      </p>
                    </div>
                  </div>

                  <span className="text-xs font-semibold shrink-0">
                    {completed ? 'Podano ✓' : 'Do podania'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Global Monthly Summary Calculator Header */}
      {activeMeds.length > 0 && (
        <div className="bg-slate-900 text-white p-4 sm:p-5 rounded-3xl shadow-sm border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-teal-500/20 text-teal-400 rounded-xl">
                <Calculator className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm sm:text-base">Miesięczne Zapotrzebowanie na Leki</h3>
                <p className="text-[11px] text-slate-400">Automatyczne przeliczenie dawek (np. 3/4 tab rano i wieczorem)</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            {activeMeds.map((med) => {
              const demand = calculateMedicationDemand(med);
              const unitWord = med.form === 'tablet' ? 'tabletek' : med.form === 'capsule' ? 'kapsułek' : 'dawek';

              return (
                <div key={med.id} className="bg-slate-800/80 border border-slate-700/70 p-3 rounded-2xl flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="font-bold text-slate-100 text-xs block">{med.name}</span>
                      <span className="text-[11px] text-teal-400 font-semibold">
                        {med.timesOfDay.map(t => `${t.label}: ${t.amount}`).join(' + ')}
                      </span>
                    </div>
                    <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full font-medium">
                      {demand.dailyUnits} {unitWord}/dzień
                    </span>
                  </div>

                  <div className="mt-2 pt-2 border-t border-slate-700/60 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Potrzeba na 30 dni:</span>
                    <strong className="text-emerald-400 font-extrabold text-sm">
                      {demand.monthlyUnits} {unitWord}
                      {demand.packagesNeededMonthly && (
                        <span className="text-slate-300 font-normal text-[11px] ml-1">
                          (~{demand.packagesNeededMonthly} op.)
                        </span>
                      )}
                    </strong>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Active Medications List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <span>Aktywne kuracje i leki</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-bold">
              {activeMeds.length}
            </span>
          </h3>
          <span className="text-xs text-slate-400">Synchronizuj z kalendarzem</span>
        </div>

        {activeMeds.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-slate-200 text-slate-500">
            <Pill className="w-12 h-12 text-slate-300 mx-auto mb-2" />
            <p className="font-semibold text-sm text-slate-700">Brak aktywnych leków</p>
            <p className="text-xs text-slate-400 mt-1">
              Dodaj leki z dawkowaniem (np. 3/4 tabletki), a kalkulator wyliczy ile tabletek potrzebujesz na miesiąc.
            </p>
            <button
              onClick={handleOpenAdd}
              className="mt-4 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow"
            >
              Dodaj pierwszy lek
            </button>
          </div>
        ) : (
          activeMeds.map((med) => {
            const demand = calculateMedicationDemand(med);
            const unitLabel = med.form === 'tablet' ? 'tabletek' : med.form === 'capsule' ? 'kapsułek' : 'dawek';

            return (
              <div
                key={med.id}
                className="bg-white rounded-3xl p-5 shadow-sm border border-slate-200/80 space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-lg">
                        {med.form === 'drops' ? '💧' : med.form === 'liquid' ? '🧪' : med.form === 'ointment' ? '🧴' : '💊'}
                      </span>
                      <h4 className="font-bold text-slate-900 text-base">{med.name}</h4>
                    </div>
                    {med.activeIngredient && (
                      <p className="text-xs text-slate-400">Substancja: {med.activeIngredient}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(med)}
                      title="Edytuj lek"
                      className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteMedication(med)}
                      title="Usuń lek"
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Doses breakdown */}
                <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Pory i dawki</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {med.timesOfDay.map((slot) => (
                      <div
                        key={slot.id}
                        className="flex items-center justify-between bg-white px-3 py-1.5 rounded-xl border border-slate-200 text-xs"
                      >
                        <span className="font-semibold text-slate-800 flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-teal-600" />
                          {slot.label}: <strong>{slot.time}</strong>
                        </span>
                        <span className="font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-lg border border-teal-200">
                          {slot.amount}
                        </span>
                      </div>
                    ))}
                  </div>

                  {med.instructions && (
                    <p className="text-xs text-slate-600 mt-2 pt-2 border-t border-slate-200/60 flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                      <span>Zalecenia: <strong>{med.instructions}</strong></span>
                    </p>
                  )}
                </div>

                {/* Monthly Calculator Highlight Pill */}
                <div className="bg-teal-50/70 border border-teal-200 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-teal-600 text-white rounded-xl shadow-xs">
                      <Calculator className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-extrabold text-teal-800 tracking-wider block">
                        Zapotrzebowanie na 30 dni (1 miesiąc)
                      </span>
                      <p className="text-xs text-teal-900 font-medium">
                        Dzienne zużycie: <strong>{demand.dailyUnits} {unitLabel}/dzień</strong>
                      </p>
                    </div>
                  </div>

                  <div className="text-left sm:text-right">
                    <div className="text-base sm:text-lg font-black text-teal-900 tracking-tight">
                      {demand.monthlyUnits} <span className="text-xs font-semibold text-teal-700">{unitLabel}</span>
                    </div>
                    {demand.packagesNeededMonthly && (
                      <span className="text-[11px] text-teal-700 block font-medium">
                        Potrzebne: <strong>{demand.packagesNeededMonthly}</strong> {demand.packagesNeededMonthly === 1 ? 'opakowanie' : demand.packagesNeededMonthly < 5 ? 'opakowania' : 'opakowań'} ({med.packageSize} szt.)
                      </span>
                    )}
                  </div>
                </div>

                {/* Stock alert if entered */}
                {demand.daysLeftWithStock !== undefined && (
                  <div className={`p-2.5 rounded-xl border text-xs flex items-center justify-between ${
                    demand.daysLeftWithStock <= 5 
                      ? 'bg-rose-50 border-rose-200 text-rose-800' 
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}>
                    <span className="flex items-center gap-1.5 font-medium">
                      <Package className="w-3.5 h-3.5" />
                      Zapas w domu: <strong>{med.currentStock} {unitLabel}</strong>
                    </span>
                    <span className="font-bold">
                      Wystarczy na: ~{demand.daysLeftWithStock} {demand.daysLeftWithStock === 1 ? 'dzień' : 'dni'}
                    </span>
                  </div>
                )}

                {/* Treatment details */}
                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span>
                    {med.isChronic ? 'Kuracja stała / przewlekła' : `Kuracja do: ${med.endDate || 'zakończenia objawów'}`}
                  </span>
                  <span>Rozpoczęto: {med.startDate}</span>
                </div>

                {/* Calendar Integration Bar */}
                <div className="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <CalendarIcon className="w-4 h-4 text-teal-600" />
                    <span>Dodaj do kalendarza:</span>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    {/* Google Calendar */}
                    <button
                      onClick={() => handleAddToGoogleCalendar(med)}
                      title="Dodaj powiadomienie do Kalendarza Google"
                      className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-50 text-blue-700 hover:bg-blue-100 text-xs font-semibold transition"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Google Kalendarz
                    </button>

                    {/* Phone Calendar (.ics) */}
                    <button
                      onClick={() => handleDownloadPhoneCalendar(med)}
                      title="Pobierz plik przypomnienia do kalendarza w telefonie (.ics)"
                      className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-50 text-teal-800 hover:bg-teal-100 text-xs font-semibold transition"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Kalendarz w telefonie (.ics)
                    </button>

                    {/* Quick Delete */}
                    <button
                      onClick={() => handleDeleteMedication(med)}
                      title="Usuń ten lek z listy"
                      className="flex items-center justify-center gap-1 px-3 py-1.5 rounded-xl text-rose-600 hover:bg-rose-50 border border-rose-200 text-xs font-semibold transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Usuń lek</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Archived / Past Medications */}
      {archivedMeds.length > 0 && (
        <div className="space-y-2 pt-4 border-t border-slate-200">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Zakończone terapie ({archivedMeds.length})
          </h4>
          {archivedMeds.map((med) => (
            <div
              key={med.id}
              className="bg-white/60 p-3 rounded-2xl border border-slate-200 flex items-center justify-between text-xs text-slate-600"
            >
              <div>
                <span className="font-semibold text-slate-700">{med.name}</span>
                <span className="text-slate-400 ml-2">({med.dosage})</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleToggleActiveMedication(med)}
                  className="text-xs text-teal-700 hover:underline font-semibold"
                >
                  Wznów podawanie
                </button>
                <button
                  onClick={() => handleDeleteMedication(med)}
                  title="Usuń lek trwale"
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                >
                  <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Medication Modal */}
      {isAddingMed && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Pill className="w-5 h-5 text-teal-600" />
                {editingMed ? 'Edytuj lek' : 'Dodaj nowy lek i dawkowanie'}
              </h3>
              <button
                onClick={() => setIsAddingMed(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveMedication} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Nazwa leku / suplementu *</label>
                <input
                  type="text"
                  required
                  placeholder="np. Cardisure, Apoquel, Encorton, Onsior"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-sm font-bold text-slate-900 focus:outline-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Postać leku</label>
                  <select
                    value={formForm}
                    onChange={(e) => setFormForm(e.target.value as any)}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  >
                    <option value="tablet">Tabletka (możliwe dawki ułamkowe np. 3/4)</option>
                    <option value="capsule">Kapsułka</option>
                    <option value="liquid">Syrop / Płyn</option>
                    <option value="drops">Krople (oczy / uszy)</option>
                    <option value="ointment">Maść</option>
                    <option value="injection">Zastrzyk</option>
                    <option value="paste">Pasta</option>
                    <option value="powder">Proszek</option>
                    <option value="other">Inna</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Domyślna dawka (opis)</label>
                  <input
                    type="text"
                    placeholder="np. 3/4 tabletki 2x dziennie"
                    value={formDosage}
                    onChange={(e) => setFormDosage(e.target.value)}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
              </div>

              {/* Szybki wybór popularnych ułamków dawek dla tabletek */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                  ⚡ Szybki wybór dawki (kliknij, aby ustawić dla wszystkich pór):
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {COMMON_DOSE_PRESETS.map((p) => (
                    <button
                      key={p.value}
                      type="button"
                      onClick={() => applyPresetToAllSlots(p.value)}
                      className="px-2.5 py-1 rounded-xl bg-white border border-slate-200 hover:border-teal-400 hover:bg-teal-50 text-slate-800 text-[11px] font-semibold transition active:scale-95 shadow-2xs"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dosing Times of Day Picker */}
              <div className="bg-teal-50/50 p-4 rounded-2xl border border-teal-100 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-teal-900 uppercase text-[11px] tracking-wider">
                    Pory dnia i dokładne dawki
                  </span>
                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => handleAddTimeSlot('Rano', '08:00')}
                      className="px-2 py-1 rounded-lg bg-white border border-teal-200 text-teal-800 text-[11px] font-semibold hover:bg-teal-50"
                    >
                      + Rano
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAddTimeSlot('Południe', '13:00')}
                      className="px-2 py-1 rounded-lg bg-white border border-teal-200 text-teal-800 text-[11px] font-semibold hover:bg-teal-50"
                    >
                      + Południe
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAddTimeSlot('Wieczór', '20:00')}
                      className="px-2 py-1 rounded-lg bg-white border border-teal-200 text-teal-800 text-[11px] font-semibold hover:bg-teal-50"
                    >
                      + Wieczór
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAddTimeSlot('Noc', '22:00')}
                      className="px-2 py-1 rounded-lg bg-white border border-teal-200 text-teal-800 text-[11px] font-semibold hover:bg-teal-50"
                    >
                      + Noc
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  {formTimes.map((slot) => (
                    <div
                      key={slot.id}
                      className="flex flex-col sm:flex-row sm:items-center gap-2 bg-white p-2.5 rounded-xl border border-teal-200 shadow-xs"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="Pora (np. Rano)"
                          value={slot.label}
                          onChange={(e) => handleUpdateTimeSlot(slot.id, 'label', e.target.value)}
                          className="w-24 p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />
                        <input
                          type="time"
                          value={slot.time}
                          onChange={(e) => handleUpdateTimeSlot(slot.id, 'time', e.target.value)}
                          className="w-24 p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-bold text-teal-700"
                        />
                      </div>

                      <div className="flex items-center gap-1.5 flex-1">
                        <input
                          type="text"
                          placeholder="np. 3/4 tabletki, 1/2 tab, 1 tab"
                          value={slot.amount}
                          onChange={(e) => handleUpdateTimeSlot(slot.id, 'amount', e.target.value)}
                          className="flex-1 p-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs font-semibold"
                        />

                        {/* Quick fraction chips for this specific slot */}
                        <div className="hidden sm:flex gap-1">
                          <button
                            type="button"
                            onClick={() => applyPresetToSlot(slot.id, '1/2 tabletki')}
                            className="px-1.5 py-1 text-[10px] bg-slate-100 hover:bg-teal-100 rounded text-slate-700 font-mono"
                          >
                            ½
                          </button>
                          <button
                            type="button"
                            onClick={() => applyPresetToSlot(slot.id, '3/4 tabletki')}
                            className="px-1.5 py-1 text-[10px] bg-teal-100 hover:bg-teal-200 rounded text-teal-800 font-bold font-mono"
                          >
                            ¾
                          </button>
                          <button
                            type="button"
                            onClick={() => applyPresetToSlot(slot.id, '1 tabletka')}
                            className="px-1.5 py-1 text-[10px] bg-slate-100 hover:bg-teal-100 rounded text-slate-700 font-mono"
                          >
                            1
                          </button>
                        </div>

                        {formTimes.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveTimeSlot(slot.id)}
                            className="p-1.5 text-rose-500 hover:bg-rose-50 rounded-lg"
                          >
                            ✕
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Live Monthly Demand Calculator Widget in Modal */}
                <div className="bg-white rounded-xl p-3 border border-teal-300 shadow-xs flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-teal-600" />
                    <div>
                      <span className="font-bold text-slate-800 text-[11px] block">
                        Przeliczenie zapotrzebowania miesięcznego:
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {formTimes.map(t => `${t.label}: ${t.amount || '0'}`).join(' + ')} = {Math.round(formDailyTotal * 100) / 100} / dzień
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs text-slate-500 block">30 dni:</span>
                    <strong className="text-teal-700 font-extrabold text-sm">
                      {formMonthlyDemand} {formForm === 'tablet' ? 'tabletek' : 'dawek'}
                    </strong>
                    {formPackagesMonthly && (
                      <span className="text-[10px] text-slate-400 block">
                        ({formPackagesMonthly} op. po {formPackageSize} szt.)
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Package size & current stock for smart restocking */}
              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Wielkość opakowania (szt.)
                  </label>
                  <input
                    type="number"
                    step="1"
                    placeholder="np. 30, 60, 100"
                    value={formPackageSize}
                    onChange={(e) => setFormPackageSize(e.target.value)}
                    className="w-full p-2 rounded-xl bg-white border border-slate-200 text-xs font-semibold"
                  />
                  <span className="text-[10px] text-slate-400 block mt-0.5">Do wyliczenia liczby opakowań</span>
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">
                    Aktualny zapas w domu (opcjonalnie)
                  </label>
                  <input
                    type="number"
                    step="0.25"
                    placeholder="np. 24"
                    value={formCurrentStock}
                    onChange={(e) => setFormCurrentStock(e.target.value)}
                    className="w-full p-2 rounded-xl bg-white border border-slate-200 text-xs font-semibold"
                  />
                  <span className="text-[10px] text-slate-400 block mt-0.5">Ostrzeże o wyczerpaniu zapasu</span>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">
                  Zalecenia podawania (np. z jedzeniem / na czczo)
                </label>
                <input
                  type="text"
                  placeholder="np. Podawać z posiłkiem, nie dzielić kapsułki, przed snem"
                  value={formInstructions}
                  onChange={(e) => setFormInstructions(e.target.value)}
                  className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Data rozpoczęcia</label>
                  <input
                    type="date"
                    value={formStartDate}
                    onChange={(e) => setFormStartDate(e.target.value)}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Typ kuracji</label>
                  <select
                    value={formIsChronic ? 'chronic' : 'temp'}
                    onChange={(e) => setFormIsChronic(e.target.value === 'chronic')}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  >
                    <option value="chronic">Lek stały (przewlekły)</option>
                    <option value="temp">Terapia czasowa</option>
                  </select>
                </div>
              </div>

              {!formIsChronic && (
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Data zakończenia kuracji</label>
                  <input
                    type="date"
                    value={formEndDate}
                    onChange={(e) => setFormEndDate(e.target.value)}
                    className="w-full p-2 rounded-xl bg-slate-50 border border-slate-200 text-xs"
                  />
                </div>
              )}

              <div className="flex gap-2 pt-2">
                {editingMed && (
                  <button
                    type="button"
                    onClick={() => handleDeleteMedication(editingMed)}
                    className="px-3 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold transition flex items-center gap-1.5"
                  >
                    <Trash2 className="w-4 h-4 text-rose-600" />
                    <span>Usuń</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsAddingMed(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold transition"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold shadow transition"
                >
                  {editingMed ? 'Zapisz zmiany' : 'Dodaj lek do listy'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {medicationToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-center text-slate-800">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Usunąć lek „{medicationToDelete.name}”?
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Lek oraz wszystkie powiązane z nim pory i wpisy dawkowania zostaną trwale usunięte z aplikacji.
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setMedicationToDelete(null)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition"
              >
                Anuluj
              </button>
              <button
                type="button"
                onClick={confirmDeleteMedication}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow transition active:scale-95 flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                Tak, usuń lek
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
