export type Species = 'dog' | 'cat' | 'rabbit' | 'ferret' | 'bird' | 'other';

export type Gender = 'male' | 'female';

export interface PetWeightEntry {
  id: string;
  date: string; // YYYY-MM-DD
  weightKg: number;
  notes?: string;
}

export interface Pet {
  id: string;
  name: string;
  species: Species;
  breed: string;
  gender: Gender;
  birthDate: string; // YYYY-MM-DD
  weightKg: number;
  chipNumber: string;
  tattooNumber?: string;
  passportNumber?: string;
  color: string;
  isNeutered: boolean;
  photoUrl: string;
  allergies?: string;
  bloodType?: string;
  specialNotes?: string;
  vetClinicName?: string;
  vetDoctorName?: string;
  vetPhone?: string;
  emergencyClinicPhone?: string;
  bookletScans?: { id: string; url: string; title: string; date: string }[]; // skany fizycznej książeczki zdrowia
  weightHistory: PetWeightEntry[];
  createdAt: string;
}

export type VaccineStatus = 'valid' | 'expiring_soon' | 'expired';

export interface Vaccination {
  id: string;
  petId: string;
  name: string; // np. Wścieklizna (Rabisin), Choroby zakaźne (Nobivac DHPPi), Leptospiroza
  category: 'rabies' | 'core' | 'non_core' | 'other';
  dateAdministered: string; // YYYY-MM-DD
  validUntil: string; // YYYY-MM-DD
  batchNumber?: string; // nr serii
  vetClinic?: string;
  vetDoctor?: string;
  notes?: string;
  attachmentUrls?: string[]; // scans/photos of passport entry or certificate
}

export type ExamResultStatus = 'normal' | 'attention' | 'abnormal';

export interface MedicalExam {
  id: string;
  petId: string;
  title: string; // np. Morfologia i biochemia krwi, USG jamy brzusznej, RTG stawów biodrowych
  category: 'blood' | 'urine' | 'ultrasound' | 'xray' | 'feces' | 'cardio' | 'cytology' | 'ophthalmic' | 'other';
  date: string; // YYYY-MM-DD
  clinic?: string;
  doctor?: string;
  status: ExamResultStatus;
  summary: string;
  keyParameters?: { name: string; value: string; unit?: string; refRange?: string; isFlagged?: boolean }[];
  scans: { id: string; url: string; title: string; date: string }[];
  nextRecommendedDate?: string;
}

export type DiseaseStatus = 'active' | 'chronic' | 'cured' | 'monitoring';

export interface MedicalCondition {
  id: string;
  petId: string;
  name: string; // np. Atopowe zapalenie skóry, Przewlekła niewydolność nerek
  diagnosisDate: string; // YYYY-MM-DD
  status: DiseaseStatus;
  symptoms: string;
  treatment: string;
  vetNotes?: string;
  resolvedDate?: string;
}

export interface VetVisit {
  id: string;
  petId: string;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  reason: string; // Kontrola, Szczepienie, Badanie krwi, Zabieg chirurgiczny, Pilna wizyta
  clinic: string;
  doctor?: string;
  diagnosis?: string;
  treatmentGiven?: string;
  costPln?: number;
  nextAppointmentDate?: string;
  notes?: string;
}

export type MedicationForm = 'tablet' | 'capsule' | 'liquid' | 'drops' | 'ointment' | 'injection' | 'paste' | 'powder' | 'other';

export type TimeOfDayKey = 'morning' | 'noon' | 'evening' | 'night' | 'custom';

export interface DoseScheduleItem {
  id: string;
  label: string; // np. Rano, Południe, Wieczór, Noc, lub niestandardowa godzina
  time: string; // HH:mm format, np. 08:00
  amount: string; // np. "1/2 tabletki", "2.5 ml", "1 kropla"
}

export interface Medication {
  id: string;
  petId: string;
  name: string; // np. Cardisure, Onsior, Encorton, Bravecto
  activeIngredient?: string; // substancja czynna
  form: MedicationForm;
  dosage: string; // ogólna dawka np. "5 mg" lub "1 tab 2x dziennie"
  timesOfDay: DoseScheduleItem[]; // wybrane pory dnia i dokładne godziny
  instructions?: string; // np. "Podawać z mokrą karmą", "Na czczo 1h przed jedzeniem"
  startDate: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD lub puste jeśli przewlekłe
  isChronic: boolean; // czy lek stały
  isActive: boolean; // czy aktualnie przyjmowany
  packageSize?: number; // ile tabletek w opakowaniu (np. 30, 60, 100)
  currentStock?: number; // aktualny stan zapasów (np. 24 tabletki)
  vetPrescribedBy?: string;
  notes?: string;
}

export interface DoseLogEntry {
  id: string;
  petId: string;
  medicationId: string;
  scheduledDate: string; // YYYY-MM-DD
  time: string; // HH:mm
  takenAt: string; // ISO string when clicked
  completed: boolean;
  notes?: string;
}
